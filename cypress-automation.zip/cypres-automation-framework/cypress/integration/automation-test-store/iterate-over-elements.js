/// <reference types="Cypress" />

describe("Iterate over elements", () => {
    it("Log information of all hair care products", () => {
        //cypres code
        cy.visit('https://automationteststore.com/')
        
        cy.get('a[href*="product/category&path="]').contains('Hair Care').click()
        
        cy.get('.fixed_wrapper .prdocutname').each(($el, index, $list) => {
            cy.log("Index: " + index + " : " + $el.text())
        })
  
    })

    it("Log information of all hair care products", () => {
        //cypres code
        cy.visit('https://automationteststore.com/')
        
        cy.get('a[href*="product/category&path="]').contains('Hair Care').click()
        
        cy.get('.fixed_wrapper .prdocutname').each(($el, index, $list) => {
            if($el.text().includes('Pantene Pro-V Conditioner, Classic Care')) {
                cy.wrap($el).click()
            }
        })
  
    })
});