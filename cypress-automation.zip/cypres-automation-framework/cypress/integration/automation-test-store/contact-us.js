/// <reference types="Cypress" />

describe("Test Contact Us form via Automation Test Store", () => {
    it("Should be able to submit a successful submission via contact us form", () => {
        //cypres code
        cy.visit('https://automationteststore.com/')
        cy.get("a[href$='contact']").click().then(function (indexTextHeader){
            cy.log("The text of element was " + indexTextHeader.text())
        })
        // cy.get('.info_links_footer > :nth-child(5) > a').click()
        // cy.xpath("//a[contains(@href, 'contact')]").click()
        cy.get('#ContactUsFrm_first_name').type('Syrius')
        cy.get('#ContactUsFrm_email').type('syrius@star.com.pl')
        cy.get('#ContactUsFrm_email').should('have.attr', 'name', 'email')
        cy.get('#ContactUsFrm_enquiry').type('Do you still livin?')
        cy.get('button[title="Submit"]').click()
        cy.get('.mb40 > :nth-child(3)').should('have.text', 'Your enquiry has been successfully sent to the store owner!')
    })
});