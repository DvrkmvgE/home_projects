/// <reference types="Cypress" />

describe("Iterate over elements", () => {
    it("Log information of all hair care products", () => {
        //cypres code
        cy.visit('https://automationteststore.com/')
        
        cy.get('a[href*="product/category&path="]').contains('Hair Care').click()
        
        cy.get('.thumbnail').as('liLength')
        
        cy.get('@liLength').find('.productcart').invoke('attr', 'title').should('include', 'Add to Cart')

    })
})
