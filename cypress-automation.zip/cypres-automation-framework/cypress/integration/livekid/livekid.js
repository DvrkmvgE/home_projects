/// <reference types="Cypress" />

describe("Iterate over elements", () => {
    it("XHR tests", () => {
        //cypres code
        cy.visit('https://app.livekid.com/')
    })
})


