/// <reference types="Cypress" />

describe("Test Contact Us form via WebdriverUni", () => {
    it("Should be able to submit a successful submission via contact us form", () => {
        //cypres code
        cy.visit("http://www.webdriveruniversity.com/Contact-Us/contactus.html")
        cy.title().should('include', 'WebDriver')
        cy.url().should('include', 'contact')
        cy.document().should('have.property', 'charset').and('eq', 'UTF-8')
        cy.get('[name="first_name"]').type("Joe")
        cy.get('[name="last_name"]').type('Mood')
        cy.get('[name="email"]').type('joe@mood.com.pl')
        cy.get('textarea.feedback-input').type('no comment')
        cy.get('[type="submit"]').click()
        cy.xpath('//div[contains(@id,"contact_reply")]/h1').should('have.text', 'Thank You for your Message!')
        
    })

    it("Should not be able to submit a successful submission via contact us form as all fields are required", () => {
        //cypres code
        cy.visit("http://www.webdriveruniversity.com/Contact-Us/contactus.html")
        cy.get('[name="first_name"]').type("Joe")
        cy.get('[name="last_name"]').type('Mood')
        cy.get('textarea.feedback-input').type('no comment')
        cy.get('[type="submit"]').click()
        cy.get('body').contains('Error: all fields are required').then(function (indexText){
            cy.log('The text is: "' + indexText.text() + '"')
        })
        cy.get('body').should('include.text', 'Error: all fields are required')
        
    })
});


//czego się nauczyczyłem w tym projekcie?? 
//cy.get('#contact-us').click({force: true}) -> gdy obiekt ma 0 px lub jest nieklikalny dla normalnego usera możemy na kliku wymusić opcję force, która jest domyślnie wyłączona;
// /// <reference types="Cypress" /> -> jak dodamy to na samą górę doc'a to w VS mamy dostęp do dokumentacji Cypressa; 
//  xpath - wklejamy se xpath, do nauki z w3schools, albo kopiując z przeglądarki ppm na elementi copy as xpath - działa; 
// should - to takie komendy z CHAI - chai pomaga nam sprawdzic, czy jakis element zawiera to co chcemy ;) 
// describe / it - opisuje poszczególny test według standardu mocha; 
// it.only - wykonuje pojedynczy test jeśli piszemy więcej testów jest to bardzo przydatne przy pracy; 