/// <reference types="Cypress" />
describe("Selector examples", () => {
    it("Examples selectors via page", () => {
        cy.visit("http://www.webdriveruniversity.com/Contact-Us/contactus.html")
        
        cy.get('input')
        cy.get('input[name="first_name"]')
        cy.get('#contact_me')
        cy.get('.feedback-input')
        cy.get('[class="navbar navbar-inverse navbar-fixed-top]')
        cy.get('[name="email"][placeholder="Email Adress"]')
        cy.xpath('//input[@name="first_name"]')
    })
})